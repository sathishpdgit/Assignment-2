Student = 100
Total_class = 4.0
Teachers = 30
Department = 90
Members = Student - Teachers
Staf = Teachers
Capacity = Staf * Total_class
Average_school = Department / Staf


puts "There are #{Student} Student available."
puts "There are only #{Teachers} Teachers available."
puts "There will be #{Members}  members ."
puts "We can transport #{Capacity} people today."
puts "We have #{Department} to Department today."
puts "We need to put about #{Average_school} in each Student."
