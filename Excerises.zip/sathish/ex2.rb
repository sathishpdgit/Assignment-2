# My profile information
 # Please veriy the Program

puts "My Self Sathish" # This is my first name

# You can also use a comment to "disable" or comment out a piece of code:
 # puts "Disable Code."
puts  "hi # there."



puts "This will run."
