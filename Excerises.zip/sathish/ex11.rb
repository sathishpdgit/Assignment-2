print "Whats your name ? "
name = gets.chomp
print "Degree and Qualification ? "
deg = gets.chomp
print "Percentage and CGPA  ?"
per = gets.chomp

puts "So, Your Good Name #{name} ,Your Qualification #{deg}  and #{per} In collage/university."