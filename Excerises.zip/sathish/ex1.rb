puts "Hello World!"
puts "Hello INDIA"
puts "I like INDIA."
puts "GOOD MORNING."
puts "Yay! vERIFIYING."
puts "I'd much rather you 'not'."
puts 'I "said" do not touch this.'
