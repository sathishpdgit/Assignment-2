a = "\t Sathish."

# New Line
b = "B.Tech\nInformation Technology." 
# Escape
d = "B.Tech\eInformation Technology."
# Formford
e = "B.Tech\fInformation Technology."
# Bell/alert
f = "B.Tech\aInformation Technology."
# Return
g = "B.Tech\rInformation Technology."
# Space
h = "B.Tech\sInformation Technology."
# Vertical Tab
i = "B.Tech\vInformation Technology."

c = "percentage and CGPA \\ 76 \\ 75."


Percentages = """
My school and Collage Percentage:
\t* 76%
\t* 77%
\t* 69.9%
"""

puts a
puts b
puts c

puts d
puts e
puts f


puts g
puts h
puts i



puts Percentages




