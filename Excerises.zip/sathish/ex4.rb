# Addition
puts 5 + 2

# Subtraction
puts 100 - 7

# Multiplication
puts 8 * 8

# Division
puts 144 / 12

#astrick
puts 10*2

# Less than True
puts 2 < 5

# Less than false
puts 5 < 5 -2

# Greater than
puts 5 > 5 -2

# less than or equal
puts 5 <= -2

# greaater than or equal
puts 5 >= -2
