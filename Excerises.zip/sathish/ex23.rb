a = 20
b = 1
c = 20


if a < b
  puts "Iam Sathish"
end

if a > b
  puts "Iam Pradee"
end

if a < c
  puts "Iam spd"
end

if a > c
  puts "Love make everything"
end


c += 5

if a >= c
  puts "a are greater than or equal to c."
end

if a <= c
  puts "a are less than or equal to c."
end


if a == c
  puts "a are c."
end