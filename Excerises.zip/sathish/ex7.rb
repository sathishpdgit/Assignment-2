puts "More Printing."
puts "Printing value #{'snow'}."
puts "." * 10  # what'd that do?

a = "S"
b = "A"
c = "T"
d = "H"
e = "I"
f = "S"
g = "H"
h = "K"
i = "U"
j = "M"
k = "A"
l = "R"

# watch that print vs. puts


print a + b + c + d + e + f
puts g + h + i + j + k + l

