# Printing Printing Programe

days = "Mon Tue Wed Thu Fri Sat Sun"
months = "Jan 2020\ Feb 2020\nMar 2020\nApr 2020\nMay 2020\nJun 2020\nJul 2020 \nAug 2020"

puts "Here are the days: #{days}"
puts "Here are the months: #{months}"

puts %q{
There are week in days
year of months
}